package com.springbook.biz.user;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.springbook.biz.board.BoardVO;

public class UserServiceClient {

	public static void main(String[] args) {
		AbstractApplicationContext container = new GenericXmlApplicationContext("user/userContext.xml");
		UserService userService = (UserService) container.getBean("userService");
		
		UserVO vo = new UserVO();
		vo.setId("test");
		vo.setPassword("test1234");
		
		UserVO user = userService.getUser(vo);
		if(user!=null) System.out.println(user.getName()+"님 환영합니다. ");
		else System.out.println("로그인 실패");
		
		//1. insert into users values (?,?,?,?); 회원가입
		
		UserVO vo1 = new UserVO();
//		vo1.setId("honggd");
//		vo1.setPassword("h1234");
//		vo1.setName("홍길동");
//		vo1.setRole("User");
//		userService.insertUser(vo1);

		
		//2. update id기준 update users set password=?, role=? where id=? //회원정보수정
//		vo1.setPassword("1234");
//		vo1.setRole("Admin");
//		vo1.setId("honggd");
//		userService.updateUser(vo1);
		
		//3. delete id기준 delete from users where id=?
//		vo1.setId("honggd");
//		userService.deleteUser(vo1);
		
		//4. 전체목록 보여주기 select * from users order by name desc; //회원목록보기
//		List<UserVO> userList = userService.getBoardList(vo);
//		for(UserVO uservo : userList) {
//			System.out.println("-----> "+uservo.toString());
//		}
		
		
		//5. 선택한 아이디 정보만 보여주기 select * from users where id=? //로그인한 아이디의 정보만 보여주기
//		vo1.setId("test");
//		System.out.println(userService.selectOne(vo1));
		
		container.close();
	}

}
